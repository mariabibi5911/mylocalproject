package kotlin;

import androidx.constraintlayout.widget.ConstraintLayout;

@Metadata(d1 = {"kotlin/StandardKt__StandardKt", "kotlin/StandardKt__SynchronizedKt"}, k = 4, mv = {1, 7, 1}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_EDITOR_ABSOLUTEX)
/* loaded from: classes7.dex */
public final class StandardKt extends StandardKt__SynchronizedKt {
    private StandardKt() {
    }
}
