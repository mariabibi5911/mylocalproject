package kotlin.reflect;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.exifinterface.media.ExifInterface;
import kotlin.Metadata;

/* compiled from: typeOf.kt */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0011\u0010\u0000\u001a\u00020\u0001\"\u0006\b\u0000\u0010\u0002\u0018\u0001H\u0087\b¨\u0006\u0003"}, d2 = {"typeOf", "Lkotlin/reflect/KType;", ExifInterface.GPS_DIRECTION_TRUE, "kotlin-stdlib"}, k = 2, mv = {1, 7, 1}, xi = ConstraintLayout.LayoutParams.Table.LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE)
/* loaded from: classes7.dex */
public final class TypeOfKt {
    public static final /* synthetic */ <T> KType typeOf() {
        throw new UnsupportedOperationException("This function is implemented as an intrinsic on all supported platforms.");
    }
}
